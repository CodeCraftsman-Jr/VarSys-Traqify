#!/usr/bin/env python3
"""
Traquify Backend API - Clean Implementation
A completely new, minimal Appwrite Function for sync functionality
"""

import json
import os
from datetime import datetime
import logging

# Firebase imports
try:
    import firebase_admin
    from firebase_admin import credentials, auth, db
    import pyrebase
    FIREBASE_AVAILABLE = True
except ImportError as e:
    print(f"⚠️ Firebase libraries not available: {e}")
    FIREBASE_AVAILABLE = False

# Global variables
admin_initialized = False
pyrebase_app = None

def initialize_firebase():
    """Initialize Firebase Admin SDK and Pyrebase"""
    global admin_initialized, pyrebase_app
    
    try:
        print("🔥 Initializing Firebase...")
        
        # Get environment variables
        service_account_json = os.getenv('FIREBASE_SERVICE_ACCOUNT')
        web_config_json = os.getenv('FIREBASE_WEB_CONFIG')
        
        if not service_account_json or not web_config_json:
            print("❌ Missing Firebase environment variables")
            return False
        
        # Initialize Admin SDK
        if not admin_initialized:
            service_account = json.loads(service_account_json)
            cred = credentials.Certificate(service_account)
            firebase_admin.initialize_app(cred, {
                'databaseURL': 'https://jointjourney-a12d2-default-rtdb.asia-southeast1.firebasedatabase.app'
            })
            admin_initialized = True
            print("✅ Firebase Admin SDK initialized")
        
        # Initialize Pyrebase
        web_config = json.loads(web_config_json)
        pyrebase_app = pyrebase.initialize_app(web_config)
        print("✅ Pyrebase initialized")
        
        return True
        
    except Exception as e:
        print(f"❌ Firebase initialization failed: {e}")
        return False

def authenticate_user(email, password):
    """Authenticate user with Firebase"""
    try:
        if not pyrebase_app:
            return None, "Firebase not initialized"
        
        auth_client = pyrebase_app.auth()
        user = auth_client.sign_in_with_email_and_password(email, password)
        
        return user, None
        
    except Exception as e:
        return None, str(e)

def verify_token(id_token):
    """Verify Firebase ID token"""
    try:
        decoded_token = auth.verify_id_token(id_token)
        return decoded_token, None
    except Exception as e:
        return None, str(e)

def upload_data(uid, module, filename, data):
    """Upload data to Firebase Realtime Database"""
    try:
        # Add metadata
        data_with_metadata = {
            **data,
            'lastUpdated': datetime.now().isoformat(),
            'updatedBy': uid
        }
        
        # Store in Firebase
        ref = db.reference(f'users/{uid}/data/{module}/{filename}')
        ref.set(data_with_metadata)
        
        return True, "Data uploaded successfully"
        
    except Exception as e:
        return False, str(e)

def download_data(uid, module, filename):
    """Download data from Firebase Realtime Database"""
    try:
        ref = db.reference(f'users/{uid}/data/{module}/{filename}')
        data = ref.get()
        
        if data is None:
            return False, "No data found"
        
        return True, data
        
    except Exception as e:
        return False, str(e)

def parse_request(context):
    """Parse Appwrite Functions request"""
    try:
        print("📋 Parsing request...")
        
        # Default values
        path = '/'
        method = 'GET'
        body = {}
        headers = {}
        
        # Check if we have a request body
        if hasattr(context.req, 'body') and context.req.body:
            print(f"📝 Request body: {str(context.req.body)[:200]}...")
            
            # Parse JSON
            try:
                if isinstance(context.req.body, str):
                    data = json.loads(context.req.body)
                else:
                    data = context.req.body
                
                if isinstance(data, dict):
                    # Extract path and method
                    path = data.get('path', '/')
                    method = data.get('method', 'GET')
                    
                    print(f"✅ Extracted: {method} {path}")
                    
                    # Extract nested body
                    if 'body' in data and data['body']:
                        if isinstance(data['body'], str):
                            body = json.loads(data['body'])
                        else:
                            body = data['body']
                    
                    # Extract headers
                    headers = data.get('headers', {})
                    
                    # Handle direct auth
                    if 'email' in data and 'password' in data:
                        path = '/auth/signin'
                        method = 'POST'
                        body = data
                        
            except Exception as e:
                print(f"❌ JSON parsing failed: {e}")
        
        return path, method, body, headers
        
    except Exception as e:
        print(f"❌ Request parsing failed: {e}")
        return '/', 'GET', {}, {}

def main(context):
    """Main Appwrite Function entry point"""
    try:
        print("🚀 === CLEAN FUNCTION STARTED ===")
        print(f"⏰ Timestamp: {datetime.now().isoformat()}")
        
        # Initialize Firebase
        if not admin_initialized:
            if not initialize_firebase():
                return context.res.json({
                    'error': 'Firebase initialization failed',
                    'success': False
                }, 500)
        
        # Parse request
        path, method, body, headers = parse_request(context)
        
        print(f"🎯 Processing: {method} {path}")
        
        # Route requests
        if path == '/' or path == '/health':
            # Health check
            return context.res.json({
                'status': 'healthy',
                'service': 'Traquify Backend API - Clean',
                'platform': 'appwrite',
                'timestamp': datetime.now().isoformat(),
                'firebase_initialized': admin_initialized,
                'version': '3.0.0'
            })
        
        elif path == '/auth/signin':
            # Authentication
            email = body.get('email')
            password = body.get('password')
            
            if not email or not password:
                return context.res.json({
                    'error': 'Email and password are required',
                    'success': False
                }, 400)
            
            user, error = authenticate_user(email, password)
            
            if error:
                return context.res.json({
                    'error': error,
                    'success': False
                }, 401)
            
            return context.res.json({
                'success': True,
                'message': 'Signed in successfully',
                'user': {
                    'uid': user['localId'],
                    'email': user['email']
                },
                'idToken': user['idToken']
            })
        
        elif path.startswith('/data/'):
            # Data endpoints
            path_parts = path.strip('/').split('/')
            if len(path_parts) < 3:
                return context.res.json({
                    'error': 'Invalid data path',
                    'success': False
                }, 400)
            
            module = path_parts[1]
            filename = path_parts[2]
            
            # Validate module
            allowed_modules = ['attendance', 'budget', 'expenses', 'habits', 'income', 'investments', 'todos']
            if module not in allowed_modules:
                return context.res.json({
                    'error': 'Invalid module',
                    'success': False
                }, 400)
            
            # Get auth token
            auth_header = headers.get('Authorization') or body.get('authorization')
            if not auth_header or not auth_header.startswith('Bearer '):
                return context.res.json({
                    'error': 'Authentication required',
                    'success': False
                }, 401)
            
            token = auth_header.split('Bearer ')[1].strip()
            decoded_token, error = verify_token(token)
            
            if error:
                return context.res.json({
                    'error': 'Invalid token',
                    'success': False
                }, 401)
            
            uid = decoded_token['uid']
            
            if method == 'GET':
                # Download data
                success, result = download_data(uid, module, filename)
                
                if success:
                    return context.res.json({
                        'success': True,
                        'data': result
                    })
                else:
                    return context.res.json({
                        'error': result,
                        'success': False
                    }, 404)
            
            elif method == 'PUT':
                # Upload data
                data = body.get('data')
                if not data:
                    return context.res.json({
                        'error': 'Data is required',
                        'success': False
                    }, 400)
                
                success, result = upload_data(uid, module, filename, data)
                
                if success:
                    return context.res.json({
                        'success': True,
                        'message': result
                    })
                else:
                    return context.res.json({
                        'error': result,
                        'success': False
                    }, 500)
            
            else:
                return context.res.json({
                    'error': f'Method {method} not supported',
                    'success': False
                }, 405)
        
        else:
            # Unknown endpoint
            return context.res.json({
                'error': 'Endpoint not found',
                'success': False
            }, 404)
    
    except Exception as e:
        print(f"❌ Function error: {e}")
        return context.res.json({
            'error': 'Internal server error',
            'success': False
        }, 500)
